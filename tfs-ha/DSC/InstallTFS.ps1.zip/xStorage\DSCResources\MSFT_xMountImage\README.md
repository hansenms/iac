# Description

The resource is used to mount or unmount an ISO/VHD disk image. It can be
mounted as read-only (ISO, VHD, VHDx) or read/write (VHD, VHDx).
